package com.example.mentesa

enum class ConversationType {
    PERSONAL,
    EMOTIONAL,
    THERAPEUTIC,
    HIGHLIGHTED,
    GENERAL
}